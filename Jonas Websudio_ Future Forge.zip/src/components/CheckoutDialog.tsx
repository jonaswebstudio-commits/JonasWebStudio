import { useEffect, useState, type FormEvent } from "react";
import { X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useLanguage } from "@/lib/i18n";
import { StripeEmbeddedCheckout, type CheckoutBrief } from "@/components/StripeEmbeddedCheckout";
import { PaymentTestModeBanner } from "@/components/PaymentTestModeBanner";

interface CheckoutDialogProps {
  priceId: string;
  title: string;
  price: string;
  onClose: () => void;
}

export function CheckoutDialog({ priceId, title, price, onClose }: CheckoutDialogProps) {
  const { user } = useAuth();
  const { t } = useLanguage();
  const [brief, setBrief] = useState<CheckoutBrief | null>(null);
  const [fullName, setFullName] = useState("");
  const [businessName, setBusinessName] = useState("");
  const [notes, setNotes] = useState("");

  useEffect(() => {
    if (!user) return;
    let active = true;
    void supabase
      .from("profiles")
      .select("full_name, business_name")
      .eq("id", user.id)
      .maybeSingle()
      .then(({ data }) => {
        if (!active || !data) return;
        setFullName((v) => v || data.full_name || "");
        setBusinessName((v) => v || data.business_name || "");
      });
    return () => {
      active = false;
    };
  }, [user]);

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (user) {
      await supabase
        .from("profiles")
        .update({ full_name: fullName, business_name: businessName })
        .eq("id", user.id);
    }
    setBrief({ fullName, businessName, notes });
  };

  const field =
    "w-full rounded-2xl border border-border bg-card/60 px-5 py-3.5 text-sm text-foreground outline-none transition-colors placeholder:text-muted-foreground focus:border-primary/60";

  return (
    <div className="fixed inset-0 z-[100] flex items-start justify-center overflow-y-auto bg-background/85 p-4 backdrop-blur-md">
      <div className="relative mt-10 mb-10 w-full max-w-3xl rounded-3xl border border-border bg-card p-5 md:p-7">
        <button
          type="button"
          onClick={onClose}
          aria-label={t("close")}
          className="absolute -top-3 -right-3 rounded-full border border-border bg-card p-2 text-muted-foreground transition-colors hover:text-foreground"
        >
          <X className="h-4 w-4" />
        </button>
        <PaymentTestModeBanner />

        {brief ? (
          <div className="mt-4">
            <StripeEmbeddedCheckout
              priceId={priceId}
              brief={brief}
              returnUrl={`${window.location.origin}/checkout/return?session_id={CHECKOUT_SESSION_ID}`}
            />
          </div>
        ) : (
          <form onSubmit={onSubmit} className="mt-6">
            <p className="text-xs tracking-[0.3em] uppercase text-primary">{t("briefLabel")}</p>
            <h2 className="mt-3 text-2xl font-semibold">
              {title} — {price}
            </h2>
            <p className="mt-3 text-sm text-muted-foreground">
              A couple of details so work can start the moment your payment clears.
            </p>
            <div className="mt-6 space-y-3">
              <input
                className={field}
                placeholder={t("formName")}
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                required
              />
              <input
                className={field}
                placeholder={t("briefBusinessPh")}
                value={businessName}
                onChange={(e) => setBusinessName(e.target.value)}
              />
              <textarea
                className={`${field} min-h-28 resize-y`}
                placeholder={t("briefNotesPh")}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
              />
            </div>
            <button
              type="submit"
              className="mt-6 w-full rounded-full bg-[image:var(--gradient-neon)] px-6 py-3.5 text-sm font-semibold text-primary-foreground shadow-[var(--shadow-glow)]"
            >
              {t("briefContinue")}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
