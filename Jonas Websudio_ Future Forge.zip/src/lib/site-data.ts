export const PRICING = [
  {
    key: "tierStarter",
    price: "€245",
    priceId: "starter_website_onetime",
    features: ["f1", "f2", "f3", "f4"],
    featured: false,
  },
  {
    key: "tierGrowth",
    price: "€495",
    priceId: "growth_website_onetime",
    features: ["f5", "f6", "f7", "f8"],
    featured: true,
  },
  {
    key: "tierPremium",
    price: "€945",
    priceId: "premium_website_onetime",
    features: ["f9", "f10", "f11", "f12"],
    featured: false,
  },
] as const;

export const CARE_PLAN = {
  priceId: "care_plan_monthly",
  name: "Care Plan",
  price: "€39",
  interval: "per month",
  description: "Hosting, maintenance, security updates and small content changes — cancel anytime.",
  featureKeys: ["careF1", "careF2", "careF3", "careF4"],
} as const;

/** Packages that include a fixed post-launch support window, in months. */
export const SUPPORT_MONTHS: Record<string, number> = {
  premium_website_onetime: 3,
};
