import { createServerFn } from "@tanstack/react-start";

type ContactInput = {
  name: string;
  email: string;
  message: string;
  locale?: string | undefined;
  source?: string | undefined;
};

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export const sendContactMessage = createServerFn({ method: "POST" })
  .validator((data: ContactInput) => {
    const name = String(data?.name ?? "").trim();
    const email = String(data?.email ?? "").trim();
    const message = String(data?.message ?? "").trim();

    if (name.length < 2 || name.length > 120) throw new Error("Please enter your name.");
    if (!EMAIL_RE.test(email) || email.length > 200) throw new Error("Please enter a valid email.");
    if (message.length < 5 || message.length > 5000) throw new Error("Please write a message.");

    return {
      name,
      email,
      message,
      locale: String(data?.locale ?? "").slice(0, 8) || null,
      source: String(data?.source ?? "").slice(0, 200) || null,
    };
  })
  .handler(async ({ data }): Promise<{ ok: true }> => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.from("contact_messages").insert({
      name: data.name,
      email: data.email,
      message: data.message,
      locale: data.locale,
      source: data.source,
    });
    if (error) throw new Error(error.message);
    return { ok: true };
  });
