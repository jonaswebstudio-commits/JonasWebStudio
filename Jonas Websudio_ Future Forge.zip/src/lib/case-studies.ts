import workBarrington from "@/assets/work-barrington.jpg";
import workMeridian from "@/assets/work-meridian.jpg";
import workBella from "@/assets/work-bella.jpg";
import workIron from "@/assets/work-iron.jpg";

export type CaseStudy = {
  slug: string;
  name: string;
  /** i18n key for the short label used on the portfolio grid */
  labelKey: string;
  sector: string;
  image: string;
  /** Live preview URL embedded on the case-study page */
  previewUrl: string;
  tagline: string;
  need: string;
  built: string;
  result: string;
  highlights: { title: string; body: string }[];
  services: string[];
};

export const CASE_STUDIES: CaseStudy[] = [
  {
    slug: "barrington-and-cole",
    name: "Barrington & Cole",
    labelKey: "wLaw",
    sector: "Law firm",
    image: workBarrington,
    previewUrl: "https://id-preview--e029f316-15d8-4c03-b789-9dc242ae91fe.lovable.app",
    tagline: "Understated luxury for a full-service commercial law firm.",
    need: "Barrington & Cole were winning work through referrals alone. Their old site read like a directory listing and gave no sense of the firm's seniority, so prospective corporate clients had no reason to choose them over larger practices.",
    built: "A restrained, editorial site built around six clearly structured practice areas — Corporate & Commercial, Real Estate, Family Law, Litigation, Intellectual Property and Employment — each with its own overview, typical matters and a direct route to the partner who leads it. Deep serif typography, generous whitespace and a muted palette carry the trust cues; enquiry forms are matter-aware, so the message lands with the right team.",
    result: "Enquiries now arrive pre-qualified by practice area, and the firm reports noticeably more inbound from corporate clients who previously would not have shortlisted them.",
    highlights: [
      {
        title: "Six practice areas, one clear structure",
        body: "Every area gets a dedicated page with scope, typical matters and lead contact — no more scrolling a single wall of text.",
      },
      {
        title: "Matter-aware enquiry routing",
        body: "The contact form tags each enquiry with its practice area so it reaches the right partner immediately.",
      },
      {
        title: "Quiet, confident design language",
        body: "Serif headings, tight grid, near-monochrome palette — credibility signalled through restraint rather than decoration.",
      },
    ],
    services: ["Custom design", "Multi-page build", "Enquiry routing", "SEO foundations"],
  },
  {
    slug: "meridian-properties",
    name: "Meridian Properties",
    labelKey: "wRealEstate",
    sector: "Real estate agency",
    image: workMeridian,
    previewUrl: "https://id-preview--6f8bd3dc-3354-49a2-9616-4f62a950b81e.lovable.app",
    tagline: "A clean, upscale home for a boutique property agency.",
    need: "Meridian handled buying, selling, renting and investment consulting, but everything was funnelled through one generic contact page. Sellers and investors — their most valuable leads — had no path of their own.",
    built: "A calm, photography-led site with four distinct service journeys. Listings sit in a fast, filterable grid with large imagery and clear figures; valuation and investment enquiries each have their own short, purpose-built form. The whole thing is tuned for mobile, where most of their traffic browses in the evening.",
    result: "Listings load in under a second on mobile, and the split enquiry paths mean seller and investor leads are now identifiable the moment they arrive.",
    highlights: [
      {
        title: "Four journeys: buy, sell, rent, invest",
        body: "Each audience gets its own entry point and its own call to action instead of one catch-all form.",
      },
      {
        title: "Fast, filterable listings",
        body: "Large imagery with instant filtering by type, area and budget — built to stay quick as the portfolio grows.",
      },
      {
        title: "Instant valuation request",
        body: "A three-field form that turns casual browsers into seller leads without friction.",
      },
    ],
    services: ["Custom design", "Listings system", "Lead capture", "Performance tuning"],
  },
  {
    slug: "ember-and-oak",
    name: "Ember & Oak",
    labelKey: "wRestaurant",
    sector: "Italian restaurant",
    image: workBella,
    previewUrl: "https://id-preview--6cb6c01c-d7ac-4785-8b5d-bd3b6f059c16.lovable.app",
    tagline: "Warm, seasonal Italian dining — with bookings built in.",
    need: "Ember & Oak's menu changes with the season, but updating it meant emailing a developer. Guests were also calling to book during service, pulling staff away from the floor.",
    built: "A warm, tactile site with amber-lit photography and a seasonal menu the kitchen edits themselves — courses, dishes and allergen notes update in minutes. Reservations happen inline: date, covers and time in a single step, with confirmation by email and the evening's availability shown honestly.",
    result: "Menu changes went from days to minutes, and the floor team now takes far fewer booking calls during service.",
    highlights: [
      {
        title: "Self-managed seasonal menu",
        body: "The kitchen updates courses, dishes and allergens directly — no developer, no delay.",
      },
      {
        title: "Inline reservations",
        body: "Book in one step from any page, with instant email confirmation.",
      },
      {
        title: "Atmosphere-first art direction",
        body: "Warm tones, generous imagery and slow, quiet motion that mirrors the room itself.",
      },
    ],
    services: ["Custom design", "Menu management", "Reservations", "Photography direction"],
  },
  {
    slug: "iron-and-comb",
    name: "Iron & Comb",
    labelKey: "wBarber",
    sector: "Barbershop",
    image: workIron,
    previewUrl: "https://id-preview--1d6c1d02-c18d-4205-bbed-eed759b2fefc.lovable.app",
    tagline: "Bold, craftsman branding for a modern barbershop.",
    need: "Iron & Comb were taking every booking through DMs. Prices were inconsistent, no-shows were common, and the shop's strong in-person character didn't exist anywhere online.",
    built: "A high-contrast, heavy-type site that looks like the shop feels. Every service — cuts, beard work, hot-towel shaves and combo packages — is listed with duration and price, and each one books straight into the barber's calendar with a reminder sent the day before.",
    result: "Bookings moved off DMs almost entirely, no-shows dropped sharply thanks to reminders, and combo packages now sell without anyone having to explain them.",
    highlights: [
      {
        title: "Transparent service and combo pricing",
        body: "Cuts, beard and shave services listed with duration and price — combos priced to sell themselves.",
      },
      {
        title: "Direct calendar booking",
        body: "Pick a barber, service and slot in seconds, with an automatic reminder the day before.",
      },
      {
        title: "Workshop-grade visual identity",
        body: "Heavy condensed type, steel and ink tones, grain and texture — masculine without the cliché.",
      },
    ],
    services: ["Brand identity", "Custom design", "Online booking", "Copywriting"],
  },
];

export function getCaseStudy(slug: string) {
  return CASE_STUDIES.find((c) => c.slug === slug);
}
