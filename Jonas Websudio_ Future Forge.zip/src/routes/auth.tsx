import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { useAuth } from "@/hooks/useAuth";
import { useLanguage } from "@/lib/i18n";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";

function safeNext(value: unknown): string {
  if (typeof value !== "string") return "/account";
  if (!value.startsWith("/") || value.startsWith("//")) return "/account";
  return value;
}

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Client Sign In — Jonas Webstudio" },
      {
        name: "description",
        content:
          "Sign in to your Jonas Webstudio client account to buy a website package, track your project and manage your care plan.",
      },
      { property: "og:title", content: "Client Sign In — Jonas Webstudio" },
      {
        property: "og:description",
        content: "Access your Jonas Webstudio client area: orders, invoices and care plan.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  validateSearch: (search: Record<string, unknown>): { next?: string | undefined } => ({
    next: typeof search["next"] === "string" ? search["next"] : undefined,
  }),
  component: AuthPage,
});

function AuthPage() {
  const { next } = Route.useSearch();
  const target = safeNext(next);
  const navigate = useNavigate();
  const { isSignedIn, loading } = useAuth();
  const { t } = useLanguage();

  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [businessName, setBusinessName] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!loading && isSignedIn) void navigate({ to: target });
  }, [loading, isSignedIn, navigate, target]);

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      if (mode === "signup") {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            emailRedirectTo: `${window.location.origin}${target}`,
            data: { full_name: fullName, business_name: businessName },
          },
        });
        if (error) throw error;
        toast.success("Account created");
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
      }
      await navigate({ to: target });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setBusy(false);
    }
  };

  const onGoogle = async () => {
    setBusy(true);
    try {
      sessionStorage.setItem("post_auth_redirect", target);
      const result = await lovable.auth.signInWithOAuth("google", {
        redirect_uri: window.location.origin,
      });
      if (result.error) throw new Error(String(result.error));
      if (result.redirected) return;
      await navigate({ to: target });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Google sign-in failed");
    } finally {
      setBusy(false);
    }
  };

  const field =
    "w-full rounded-2xl border border-border bg-card/60 px-5 py-3.5 text-sm text-foreground outline-none transition-colors placeholder:text-muted-foreground focus:border-primary/60";

  return (
    <div className="min-h-screen bg-background text-foreground">
      <SiteHeader />
      <section className="relative mx-auto flex min-h-[80vh] max-w-md flex-col justify-center px-6 py-32">
        <div className="orb absolute left-1/2 top-1/3 h-[24rem] w-[24rem] -translate-x-1/2 bg-accent/20" />
        <div className="glass-panel relative rounded-3xl p-8">
          <h1 className="text-3xl font-semibold">
            {mode === "signin" ? t("authSignInTitle") : t("authSignUpTitle")}
          </h1>
          <p className="mt-3 text-sm text-muted-foreground">
            {t("authIntro")}
          </p>

          <button
            type="button"
            onClick={onGoogle}
            disabled={busy}
            className="mt-7 w-full rounded-full border border-border px-6 py-3 text-sm font-medium transition-colors hover:bg-card disabled:opacity-60"
          >
            {t("authGoogle")}
          </button>

          <div className="my-6 flex items-center gap-4 text-xs uppercase tracking-[0.2em] text-muted-foreground">
            <span className="h-px flex-1 bg-border" />
            {t("authOr")}
            <span className="h-px flex-1 bg-border" />
          </div>

          <form onSubmit={onSubmit} className="space-y-3">
            {mode === "signup" && (
              <>
                <input
                  className={field}
                  placeholder={t("formName")}
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  required
                />
                <input
                  className={field}
                  placeholder={t("briefBusinessPh")}
                  value={businessName}
                  onChange={(e) => setBusinessName(e.target.value)}
                />
              </>
            )}
            <input
              className={field}
              type="email"
              placeholder={t("authEmailPh")}
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
            <input
              className={field}
              type="password"
              placeholder={t("authPasswordPh")}
              minLength={8}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
            <button
              type="submit"
              disabled={busy}
              className="w-full rounded-full bg-[image:var(--gradient-neon)] px-6 py-3.5 text-sm font-semibold text-primary-foreground shadow-[var(--shadow-glow)] disabled:opacity-60"
            >
              {mode === "signin" ? t("authSubmitIn") : t("authSubmitUp")}
            </button>
          </form>

          <button
            type="button"
            onClick={() => setMode(mode === "signin" ? "signup" : "signin")}
            className="mt-6 w-full text-sm text-muted-foreground underline-offset-4 hover:text-foreground hover:underline"
          >
            {mode === "signin" ? t("authToggleUp") : t("authToggleIn")}
          </button>
        </div>
      </section>
      <SiteFooter />
    </div>
  );
}
