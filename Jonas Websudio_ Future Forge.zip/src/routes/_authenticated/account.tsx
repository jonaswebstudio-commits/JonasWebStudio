import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth, signOut } from "@/hooks/useAuth";
import { getStripeEnvironment } from "@/lib/stripe";
import { createPortalSession } from "@/utils/payments.functions";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";

export const Route = createFileRoute("/_authenticated/account")({
  head: () => ({
    meta: [
      { title: "Your Account — Jonas Webstudio" },
      {
        name: "description",
        content:
          "Track your Jonas Webstudio website order, project brief, support window and monthly care plan.",
      },
      { property: "og:title", content: "Your Account — Jonas Webstudio" },
      {
        property: "og:description",
        content: "Orders, invoices, support window and care plan in one place.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AccountPage,
});

type OrderRow = {
  id: string;
  product_name: string | null;
  amount_total: number | null;
  currency: string | null;
  status: string;
  support_until: string | null;
  created_at: string;
};

type SubRow = {
  id: string;
  price_id: string;
  status: string;
  current_period_end: string | null;
  cancel_at_period_end: boolean;
};

function money(amount: number | null, currency: string | null) {
  if (amount == null) return "—";
  return new Intl.NumberFormat(undefined, {
    style: "currency",
    currency: (currency ?? "eur").toUpperCase(),
  }).format(amount / 100);
}

function AccountPage() {
  const { user } = useAuth();
  const [orders, setOrders] = useState<OrderRow[]>([]);
  const [subs, setSubs] = useState<SubRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [portalBusy, setPortalBusy] = useState(false);

  const load = async () => {
    if (!user) return;
    const env = getStripeEnvironment();
    const [o, s] = await Promise.all([
      supabase
        .from("orders")
        .select("id, product_name, amount_total, currency, status, support_until, created_at")
        .eq("user_id", user.id)
        .eq("environment", env)
        .order("created_at", { ascending: false }),
      supabase
        .from("subscriptions")
        .select("id, price_id, status, current_period_end, cancel_at_period_end")
        .eq("user_id", user.id)
        .eq("environment", env)
        .order("created_at", { ascending: false }),
    ]);
    setOrders(o.data ?? []);
    setSubs(s.data ?? []);
    setLoading(false);
  };

  useEffect(() => {
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  useEffect(() => {
    if (!user) return;
    const channel = supabase
      .channel("account-orders")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "orders", filter: `user_id=eq.${user.id}` },
        () => void load(),
      )
      .subscribe();
    return () => {
      void supabase.removeChannel(channel);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  const openPortal = async () => {
    setPortalBusy(true);
    try {
      const res = await createPortalSession({
        data: { returnUrl: window.location.href, environment: getStripeEnvironment() },
      });
      if ("error" in res) throw new Error(res.error);
      window.open(res.url, "_blank", "noopener");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not open billing portal");
    } finally {
      setPortalBusy(false);
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      <SiteHeader />
      <section className="relative mx-auto max-w-5xl px-6 py-32">
        <div className="orb absolute -top-10 right-0 h-[22rem] w-[22rem] bg-primary/15" />
        <div className="relative flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="text-xs tracking-[0.3em] uppercase text-primary">Client area</p>
            <h1 className="mt-4 text-4xl font-semibold md:text-5xl">Your account</h1>
            <p className="mt-3 text-muted-foreground">{user?.email}</p>
          </div>
          <div className="flex gap-3">
            <button
              type="button"
              onClick={openPortal}
              disabled={portalBusy}
              className="rounded-full border border-border px-6 py-3 text-sm font-medium transition-colors hover:bg-card disabled:opacity-60"
            >
              Manage billing
            </button>
            <button
              type="button"
              onClick={() => void signOut()}
              className="rounded-full border border-border px-6 py-3 text-sm font-medium transition-colors hover:bg-card"
            >
              Sign out
            </button>
          </div>
        </div>

        <h2 className="mt-16 text-sm tracking-[0.2em] uppercase text-muted-foreground">Orders</h2>
        <div className="mt-5 space-y-3">
          {loading && <p className="text-sm text-muted-foreground">Loading…</p>}
          {!loading && orders.length === 0 && (
            <div className="glass-panel rounded-3xl p-8 text-sm text-muted-foreground">
              No orders yet.{" "}
              <Link to="/pricing" className="text-primary underline-offset-4 hover:underline">
                Choose a package
              </Link>
              .
            </div>
          )}
          {orders.map((o) => (
            <div
              key={o.id}
              className="glass-panel flex flex-wrap items-center justify-between gap-4 rounded-3xl p-6"
            >
              <div>
                <p className="font-medium">{o.product_name ?? "Website package"}</p>
                <p className="mt-1 text-xs text-muted-foreground">
                  {new Date(o.created_at).toLocaleDateString()} ·{" "}
                  {money(o.amount_total, o.currency)}
                  {o.support_until &&
                    ` · support until ${new Date(o.support_until).toLocaleDateString()}`}
                </p>
              </div>
              <span
                className={`rounded-full px-3 py-1 text-xs font-semibold uppercase tracking-wider ${
                  o.status === "paid"
                    ? "bg-primary/15 text-primary"
                    : o.status === "failed"
                      ? "bg-destructive/15 text-destructive"
                      : "bg-muted text-muted-foreground"
                }`}
              >
                {o.status}
              </span>
            </div>
          ))}
        </div>

        <h2 className="mt-14 text-sm tracking-[0.2em] uppercase text-muted-foreground">
          Care plan
        </h2>
        <div className="mt-5 space-y-3">
          {subs.length === 0 && (
            <div className="glass-panel rounded-3xl p-8 text-sm text-muted-foreground">
              No active care plan.
            </div>
          )}
          {subs.map((s) => (
            <div
              key={s.id}
              className="glass-panel flex flex-wrap items-center justify-between gap-4 rounded-3xl p-6"
            >
              <div>
                <p className="font-medium">Care Plan — {s.status}</p>
                <p className="mt-1 text-xs text-muted-foreground">
                  {s.current_period_end
                    ? `${s.cancel_at_period_end ? "Ends" : "Renews"} ${new Date(
                        s.current_period_end,
                      ).toLocaleDateString()}`
                    : "—"}
                </p>
              </div>
              <button
                type="button"
                onClick={openPortal}
                className="rounded-full border border-border px-5 py-2.5 text-xs font-semibold"
              >
                Manage
              </button>
            </div>
          ))}
        </div>
      </section>
      <SiteFooter />
    </div>
  );
}
