import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({
    meta: [
      { title: "Studio Orders — Jonas Webstudio" },
      {
        name: "description",
        content: "Internal Jonas Webstudio dashboard listing every website order and project brief.",
      },
      { property: "og:title", content: "Studio Orders — Jonas Webstudio" },
      { property: "og:description", content: "Internal order and brief overview." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AdminPage,
});

type Brief = { fullName?: string; businessName?: string; notes?: string };

type Message = {
  id: string;
  name: string;
  email: string;
  message: string;
  locale: string | null;
  source: string | null;
  created_at: string;
};

type Row = {
  id: string;
  customer_email: string | null;
  product_name: string | null;
  amount_total: number | null;
  currency: string | null;
  status: string;
  environment: string;
  brief: unknown;
  created_at: string;
};

function AdminPage() {
  const { user } = useAuth();
  const [isAdmin, setIsAdmin] = useState<boolean | null>(null);
  const [rows, setRows] = useState<Row[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);

  useEffect(() => {
    if (!user) return;
    let active = true;
    void (async () => {
      const { data: adminRow } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", user.id)
        .eq("role", "admin")
        .maybeSingle();
      if (!active) return;
      const admin = !!adminRow;
      setIsAdmin(admin);
      if (!admin) return;
      const { data } = await supabase
        .from("orders")
        .select(
          "id, customer_email, product_name, amount_total, currency, status, environment, brief, created_at",
        )
        .order("created_at", { ascending: false });
      if (active) setRows((data ?? []) as Row[]);
      const { data: msgs } = await supabase
        .from("contact_messages")
        .select("id, name, email, message, locale, source, created_at")
        .order("created_at", { ascending: false });
      if (active) setMessages((msgs ?? []) as Message[]);
    })();
    return () => {
      active = false;
    };
  }, [user]);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <SiteHeader />
      <section className="mx-auto max-w-6xl px-6 py-32">
        <h1 className="text-4xl font-semibold">Studio orders</h1>

        {isAdmin === false && (
          <p className="mt-6 text-muted-foreground">
            This page is for studio staff only.
          </p>
        )}

        {isAdmin && (
          <div className="mt-10 space-y-3">
            {rows.length === 0 && <p className="text-muted-foreground">No orders yet.</p>}
            {rows.map((r) => {
              const brief = (r.brief ?? {}) as Brief;
              return (
                <div key={r.id} className="glass-panel rounded-3xl p-6">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <p className="font-medium">
                      {r.product_name ?? "Package"} · {r.customer_email ?? "no email"}
                    </p>
                    <span className="text-xs uppercase tracking-wider text-muted-foreground">
                      {r.status} · {r.environment} · {new Date(r.created_at).toLocaleString()}
                    </span>
                  </div>
                  <p className="mt-2 text-sm text-muted-foreground">
                    {brief.fullName} {brief.businessName ? `· ${brief.businessName}` : ""}
                  </p>
                  {brief.notes && (
                    <p className="mt-3 rounded-2xl border border-border p-4 text-sm whitespace-pre-wrap">
                      {brief.notes}
                    </p>
                  )}
                </div>
              );
            })}
          </div>
        )}
        {isAdmin && (
          <>
            <h2 className="mt-16 text-2xl font-semibold">Contact enquiries</h2>
            <div className="mt-6 space-y-3">
              {messages.length === 0 && (
                <p className="text-muted-foreground">No messages yet.</p>
              )}
              {messages.map((m) => (
                <div key={m.id} className="glass-panel rounded-3xl p-6">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <p className="font-medium">
                      {m.name} ·{" "}
                      <a className="underline-offset-4 hover:underline" href={`mailto:${m.email}`}>
                        {m.email}
                      </a>
                    </p>
                    <span className="text-xs uppercase tracking-wider text-muted-foreground">
                      {m.locale ?? "—"} · {m.source ?? "—"} ·{" "}
                      {new Date(m.created_at).toLocaleString()}
                    </span>
                  </div>
                  <p className="mt-3 rounded-2xl border border-border p-4 text-sm whitespace-pre-wrap">
                    {m.message}
                  </p>
                </div>
              ))}
            </div>
          </>
        )}
      </section>
      <SiteFooter />
    </div>
  );
}
