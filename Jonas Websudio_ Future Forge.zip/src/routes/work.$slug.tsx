import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowLeft, ArrowUpRight, Check } from "lucide-react";
import { Reveal } from "@/components/Reveal";
import { CustomCursor } from "@/components/CustomCursor";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { CASE_STUDIES, getCaseStudy } from "@/lib/case-studies";
import { useLanguage } from "@/lib/i18n";

const SITE_URL = "https://futureforge-websudio.lovable.app";

export const Route = createFileRoute("/work/$slug")({
  loader: ({ params }) => {
    const study = getCaseStudy(params.slug);
    if (!study) throw notFound();
    return { study };
  },
  head: ({ params, loaderData }) => {
    if (!loaderData) {
      return {
        meta: [{ title: "Case study unavailable — Jonas Webstudio" }, { name: "robots", content: "noindex" }],
      };
    }
    const { study } = loaderData;
    const title = `${study.name} — ${study.sector} case study | Jonas Webstudio`;
    const description = study.tagline;
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
        { property: "og:type", content: "article" },
        { property: "og:url", content: `${SITE_URL}/work/${params.slug}` },
        { name: "twitter:card", content: "summary_large_image" },
      ],
      links: [{ rel: "canonical", href: `${SITE_URL}/work/${params.slug}` }],
    };
  },
  component: CaseStudyPage,
});

function CaseStudyPage() {
  const { study } = Route.useLoaderData();
  const { t } = useLanguage();
  const others = CASE_STUDIES.filter((c) => c.slug !== study.slug);

  return (
    <div className="min-h-screen overflow-x-hidden bg-background text-foreground">
      <CustomCursor />
      <SiteHeader />

      <main>
        {/* HERO */}
        <section className="relative overflow-hidden px-6 pt-36 pb-16">
          <div className="absolute inset-0 grid-lines opacity-40" />
          <div className="orb absolute -left-24 top-10 h-80 w-80 bg-accent/25" />
          <div className="relative mx-auto max-w-5xl">
            <Reveal>
              <Link
                to="/"
                hash="work"
                className="inline-flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-foreground"
              >
                <ArrowLeft className="h-4 w-4" />
                {t("workLabel")}
              </Link>
            </Reveal>
            <Reveal delay={100}>
              <p className="mt-8 text-xs tracking-[0.3em] uppercase text-primary">{study.sector}</p>
              <h1 className="mt-4 text-[clamp(2.5rem,7vw,5rem)] leading-[0.95] font-bold">
                {study.name}
              </h1>
              <p className="mt-6 max-w-2xl text-lg text-muted-foreground">{study.tagline}</p>
            </Reveal>
            <Reveal delay={200}>
              <ul className="mt-8 flex flex-wrap gap-2">
                {study.services.map((s) => (
                  <li
                    key={s}
                    className="glass-panel rounded-full px-4 py-1.5 text-xs tracking-wide text-muted-foreground"
                  >
                    {s}
                  </li>
                ))}
              </ul>
            </Reveal>
          </div>
        </section>

        {/* LIVE PREVIEW */}
        <section className="relative mx-auto max-w-6xl px-6">
          <Reveal>
            <div className="glass-panel glow-ring overflow-hidden rounded-3xl border border-border">
              {/* browser chrome */}
              <div className="flex items-center gap-3 border-b border-border bg-card/60 px-4 py-3">
                <div className="flex gap-1.5">
                  <span className="h-3 w-3 rounded-full bg-destructive/70" />
                  <span className="h-3 w-3 rounded-full bg-muted-foreground/50" />
                  <span className="h-3 w-3 rounded-full bg-primary/70" />
                </div>
                <div className="mx-auto hidden max-w-md flex-1 truncate rounded-full bg-background/60 px-4 py-1 text-center text-xs text-muted-foreground sm:block">
                  {study.previewUrl.replace(/^https?:\/\//, "")}
                </div>
                <a
                  href={study.previewUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 rounded-full border border-border px-3 py-1.5 text-xs font-medium text-foreground transition-colors hover:border-primary hover:text-primary"
                >
                  Open full example
                  <ArrowUpRight className="h-3.5 w-3.5" />
                </a>
              </div>
              <div className="relative bg-background">
                <img
                  src={study.image}
                  alt={`${study.name} — ${study.sector} website design by Jonas Webstudio`}
                  className="absolute inset-0 h-full w-full object-cover opacity-30"
                  aria-hidden="true"
                />
                <iframe
                  src={study.previewUrl}
                  title={`${study.name} live website preview`}
                  loading="lazy"
                  className="relative h-[70vh] min-h-[520px] w-full border-0 bg-background"
                  sandbox="allow-scripts allow-same-origin allow-popups allow-forms"
                />
              </div>
            </div>
          </Reveal>
          <Reveal delay={100}>
            <p className="mt-4 text-center text-xs text-muted-foreground">
              Live preview of the real site.{" "}
              <a
                href={study.previewUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-primary underline-offset-4 hover:underline"
              >
                Open full example in a new tab
              </a>
              .
            </p>
          </Reveal>
        </section>

        {/* STORY */}
        <section className="relative mx-auto max-w-5xl px-6 py-24">
          <div className="grid gap-10 md:grid-cols-3">
            {[
              { label: "The need", body: study.need },
              { label: "What we built", body: study.built },
              { label: "The result", body: study.result },
            ].map((block, i) => (
              <Reveal key={block.label} delay={i * 130}>
                <div className="h-full">
                  <p className="text-xs tracking-[0.3em] uppercase text-primary">{block.label}</p>
                  <p className="mt-4 text-muted-foreground">{block.body}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </section>

        {/* HIGHLIGHTS */}
        <section className="relative mx-auto max-w-6xl px-6 pb-24">
          <Reveal>
            <h2 className="text-3xl font-semibold md:text-4xl">Highlights</h2>
          </Reveal>
          <div className="mt-10 grid gap-5 md:grid-cols-3">
            {study.highlights.map((h, i) => (
              <Reveal key={h.title} delay={i * 130}>
                <div className="glass-panel glow-ring h-full rounded-3xl p-7 transition-transform duration-500 hover:-translate-y-1">
                  <Check className="h-6 w-6 text-primary" strokeWidth={1.5} />
                  <h3 className="mt-5 text-lg font-semibold">{h.title}</h3>
                  <p className="mt-3 text-sm text-muted-foreground">{h.body}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </section>

        {/* MORE WORK */}
        <section className="relative mx-auto max-w-6xl px-6 pb-24">
          <Reveal>
            <h2 className="text-2xl font-semibold">{t("workHeading")}</h2>
          </Reveal>
          <div className="mt-8 grid gap-5 sm:grid-cols-3">
            {others.map((o, i) => (
              <Reveal key={o.slug} delay={i * 120}>
                <Link
                  to="/work/$slug"
                  params={{ slug: o.slug }}
                  className="group block h-full rounded-2xl border border-border bg-card/40 p-6 transition-transform duration-500 hover:-translate-y-1"
                >
                  <p className="text-xs tracking-[0.2em] uppercase text-muted-foreground">
                    {o.sector}
                  </p>
                  <h3 className="mt-3 flex items-center gap-2 text-lg font-semibold">
                    {o.name}
                    <ArrowUpRight className="h-4 w-4 text-primary transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                  </h3>
                </Link>
              </Reveal>
            ))}
          </div>
        </section>

        {/* CTA */}
        <section className="relative overflow-hidden px-6 pb-32">
          <div className="relative mx-auto max-w-3xl text-center">
            <Reveal>
              <h2 className="text-[clamp(2rem,5vw,3.5rem)] leading-[1] font-bold">
                {t("contactHeading")}
              </h2>
              <p className="mt-5 text-muted-foreground">{t("contactSub")}</p>
              <Link
                to="/"
                hash="contact"
                className="mt-8 inline-flex items-center gap-2 rounded-full bg-[image:var(--gradient-neon)] px-7 py-3.5 text-sm font-semibold text-primary-foreground shadow-[var(--shadow-glow)] transition-transform hover:scale-[1.03]"
              >
                {t("heroCta1")}
                <ArrowUpRight className="h-4 w-4" />
              </Link>
            </Reveal>
          </div>
        </section>
      </main>

      <SiteFooter />
    </div>
  );
}
