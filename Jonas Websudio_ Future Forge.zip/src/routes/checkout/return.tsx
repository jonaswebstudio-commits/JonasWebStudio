import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { CheckCircle2, Clock, Loader2 } from "lucide-react";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { getStripeEnvironment } from "@/lib/stripe";
import { getCheckoutStatus } from "@/utils/payments.functions";

export const Route = createFileRoute("/checkout/return")({
  head: () => ({
    meta: [
      { title: "Order Confirmed — Jonas Webstudio" },
      {
        name: "description",
        content:
          "Your website package order is confirmed. We'll be in touch within hours to kick off your project.",
      },
      { property: "og:title", content: "Order Confirmed — Jonas Webstudio" },
      {
        property: "og:description",
        content: "Thanks for your order — your new website project starts now.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  validateSearch: (search: Record<string, unknown>): { session_id?: string | undefined } => ({
    session_id: typeof search["session_id"] === "string" ? search["session_id"] : undefined,
  }),
  component: CheckoutReturn,
});

type State =
  | { kind: "loading" }
  | { kind: "none" }
  | { kind: "error"; message: string }
  | { kind: "pending" }
  | { kind: "paid"; product: string | null; amount: number | null; currency: string | null };

function CheckoutReturn() {
  const { session_id: sessionId } = Route.useSearch();
  const [state, setState] = useState<State>({ kind: "loading" });

  useEffect(() => {
    if (!sessionId) {
      setState({ kind: "none" });
      return;
    }
    let active = true;
    void (async () => {
      const res = await getCheckoutStatus({
        data: { sessionId, environment: getStripeEnvironment() },
      });
      if (!active) return;
      if ("error" in res) {
        setState({ kind: "error", message: res.error });
      } else if (res.paymentStatus === "unpaid" && res.mode === "payment") {
        setState({ kind: "pending" });
      } else {
        setState({
          kind: "paid",
          product: res.productName,
          amount: res.amountTotal,
          currency: res.currency,
        });
      }
    })();
    return () => {
      active = false;
    };
  }, [sessionId]);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <SiteHeader />
      <section className="relative mx-auto flex min-h-[70vh] max-w-2xl flex-col items-center justify-center px-6 py-32 text-center">
        <div className="orb absolute left-1/2 top-1/2 h-[26rem] w-[26rem] -translate-x-1/2 -translate-y-1/2 bg-accent/25" />
        <div className="glass-panel relative rounded-3xl p-10">
          {state.kind === "loading" && (
            <>
              <Loader2 className="mx-auto h-10 w-10 animate-spin text-primary" strokeWidth={1.5} />
              <h1 className="mt-6 text-2xl font-semibold">Confirming your payment…</h1>
            </>
          )}
          {state.kind === "paid" && (
            <>
              <CheckCircle2 className="mx-auto h-12 w-12 text-primary" strokeWidth={1.5} />
              <h1 className="mt-6 text-3xl font-semibold md:text-4xl">Order confirmed</h1>
              <p className="mt-4 text-muted-foreground">
                {state.product ? `${state.product} — ` : ""}
                {state.amount != null
                  ? new Intl.NumberFormat(undefined, {
                      style: "currency",
                      currency: (state.currency ?? "eur").toUpperCase(),
                    }).format(state.amount / 100)
                  : ""}
              </p>
              <p className="mt-3 text-muted-foreground">
                Your payment went through. We'll email you within hours to start the discovery step
                — your brief is already with us.
              </p>
              <Link
                to="/account"
                className="mt-8 inline-flex rounded-full bg-[image:var(--gradient-neon)] px-6 py-3 text-sm font-semibold text-primary-foreground"
              >
                View your order
              </Link>
            </>
          )}
          {state.kind === "pending" && (
            <>
              <Clock className="mx-auto h-12 w-12 text-primary" strokeWidth={1.5} />
              <h1 className="mt-6 text-3xl font-semibold">Payment processing</h1>
              <p className="mt-4 text-muted-foreground">
                Your bank is still settling this payment. We'll confirm by email as soon as it
                clears, and your account will update automatically.
              </p>
            </>
          )}
          {state.kind === "error" && (
            <>
              <h1 className="text-3xl font-semibold">We couldn't confirm this order</h1>
              <p className="mt-4 text-muted-foreground">{state.message}</p>
            </>
          )}
          {state.kind === "none" && (
            <>
              <h1 className="text-3xl font-semibold md:text-4xl">No order found</h1>
              <p className="mt-4 text-muted-foreground">
                We couldn't find checkout details for this page.
              </p>
            </>
          )}
          <Link
            to="/pricing"
            className="mt-8 inline-flex rounded-full border border-border px-6 py-3 text-sm font-medium"
          >
            Back to pricing
          </Link>
        </div>
      </section>
      <SiteFooter />
    </div>
  );
}
