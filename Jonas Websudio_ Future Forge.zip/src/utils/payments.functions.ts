import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import {
  type StripeEnv,
  createStripeClient,
  getStripeErrorMessage,
} from "@/lib/stripe.server";

type CheckoutSessionResult = { clientSecret: string } | { error: string };

type Brief = {
  fullName: string;
  businessName?: string | undefined;
  notes?: string | undefined;
};

async function resolveOrCreateCustomer(
  stripe: ReturnType<typeof createStripeClient>,
  options: { email?: string | undefined; userId: string },
): Promise<string> {
  if (!/^[a-zA-Z0-9_-]+$/.test(options.userId)) throw new Error("Invalid userId");

  const found = await stripe.customers.search({
    query: `metadata['userId']:'${options.userId}'`,
    limit: 1,
  });
  if (found.data.length) return found.data[0]!.id;

  if (options.email) {
    const existing = await stripe.customers.list({ email: options.email, limit: 1 });
    if (existing.data.length) {
      const customer = existing.data[0]!;
      if (customer.metadata?.["userId"] !== options.userId) {
        await stripe.customers.update(customer.id, {
          metadata: { ...customer.metadata, userId: options.userId },
        });
      }
      return customer.id;
    }
  }

  const created = await stripe.customers.create({
    ...(options.email && { email: options.email }),
    metadata: { userId: options.userId },
  });
  return created.id;
}

export const createCheckoutSession = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator(
    (data: {
      priceId: string;
      returnUrl: string;
      environment: StripeEnv;
      brief: Brief;
    }) => {
      if (!/^[a-zA-Z0-9_-]+$/.test(data.priceId)) throw new Error("Invalid priceId");
      if (!data.brief?.fullName?.trim()) throw new Error("Your name is required");
      return data;
    },
  )
  .handler(async ({ data, context }): Promise<CheckoutSessionResult> => {
    try {
      const { supabase, userId } = context;
      const {
        data: { user },
      } = await supabase.auth.getUser();
      const email = user?.email ?? undefined;

      const stripe = createStripeClient(data.environment);

      const prices = await stripe.prices.list({ lookup_keys: [data.priceId] });
      if (!prices.data.length) throw new Error("Price not found");
      const stripePrice = prices.data[0]!;
      const isRecurring = stripePrice.type === "recurring";

      const productId =
        typeof stripePrice.product === "string" ? stripePrice.product : stripePrice.product.id;
      const product = await stripe.products.retrieve(productId);

      const customerId = await resolveOrCreateCustomer(stripe, { email, userId });

      const brief = {
        fullName: data.brief.fullName.slice(0, 200),
        businessName: (data.brief.businessName ?? "").slice(0, 200),
        notes: (data.brief.notes ?? "").slice(0, 2000),
      };

      const session = await stripe.checkout.sessions.create({
        line_items: [{ price: stripePrice.id, quantity: 1 }],
        mode: isRecurring ? "subscription" : "payment",
        ui_mode: "embedded_page",
        return_url: data.returnUrl,
        customer: customerId,
        automatic_tax: { enabled: true },
        customer_update: { address: "auto", name: "auto" },
        ...(!isRecurring && { payment_intent_data: { description: product.name } }),
        metadata: {
          userId,
          priceId: data.priceId,
          productName: product.name,
          managed_payments: "false",
          brief_name: brief.fullName,
          brief_business: brief.businessName,
          brief_notes: brief.notes,
        },
        ...(isRecurring && { subscription_data: { metadata: { userId } } }),
      });

      // Record the intent immediately so nothing is lost if the buyer
      // abandons checkout or the webhook is delayed.
      if (!isRecurring) {
        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        await supabaseAdmin.from("orders").upsert(
          {
            user_id: userId,
            customer_email: email ?? null,
            price_id: data.priceId,
            product_name: product.name,
            amount_total: stripePrice.unit_amount ?? null,
            currency: stripePrice.currency,
            status: "pending",
            stripe_session_id: session.id,
            stripe_customer_id: customerId,
            brief,
            environment: data.environment,
          },
          { onConflict: "stripe_session_id" },
        );
      }

      return { clientSecret: session.client_secret ?? "" };
    } catch (error) {
      return { error: getStripeErrorMessage(error) };
    }
  });

type CheckoutStatus =
  | {
      status: string;
      paymentStatus: string;
      productName: string | null;
      amountTotal: number | null;
      currency: string | null;
      mode: string;
    }
  | { error: string };

/** Verifies a checkout session with Stripe instead of trusting the return URL. */
export const getCheckoutStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((data: { sessionId: string; environment: StripeEnv }) => {
    if (!/^[a-zA-Z0-9_]+$/.test(data.sessionId)) throw new Error("Invalid session id");
    return data;
  })
  .handler(async ({ data, context }): Promise<CheckoutStatus> => {
    try {
      const stripe = createStripeClient(data.environment);
      const session = await stripe.checkout.sessions.retrieve(data.sessionId);

      if (session.metadata?.["userId"] && session.metadata["userId"] !== context.userId) {
        return { error: "This order belongs to a different account" };
      }

      // Reconcile in case the webhook has not landed yet.
      if (session.payment_status !== "unpaid" && session.mode === "payment") {
        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        await supabaseAdmin
          .from("orders")
          .update({ status: "paid" })
          .eq("stripe_session_id", session.id)
          .eq("status", "pending");
      }

      return {
        status: session.status ?? "unknown",
        paymentStatus: session.payment_status ?? "unknown",
        productName: session.metadata?.["productName"] ?? null,
        amountTotal: session.amount_total ?? null,
        currency: session.currency ?? null,
        mode: session.mode ?? "payment",
      };
    } catch (error) {
      return { error: getStripeErrorMessage(error) };
    }
  });

type PortalResult = { url: string } | { error: string };

export const createPortalSession = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((data: { returnUrl?: string | undefined; environment: StripeEnv }) => data)
  .handler(async ({ data, context }): Promise<PortalResult> => {
    try {
      const { supabase, userId } = context;

      const { data: sub } = await supabase
        .from("subscriptions")
        .select("stripe_customer_id")
        .eq("user_id", userId)
        .eq("environment", data.environment)
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();

      let customerId = sub?.stripe_customer_id ?? null;

      if (!customerId) {
        const { data: order } = await supabase
          .from("orders")
          .select("stripe_customer_id")
          .eq("user_id", userId)
          .eq("environment", data.environment)
          .not("stripe_customer_id", "is", null)
          .order("created_at", { ascending: false })
          .limit(1)
          .maybeSingle();
        customerId = order?.stripe_customer_id ?? null;
      }

      if (!customerId) return { error: "No billing account found yet" };

      const stripe = createStripeClient(data.environment);
      const portal = await stripe.billingPortal.sessions.create({
        customer: customerId,
        ...(data.returnUrl && { return_url: data.returnUrl }),
      });
      return { url: portal.url };
    } catch (error) {
      return { error: getStripeErrorMessage(error) };
    }
  });
