# Jonas Websudio: Future Forge

Create a stunning, futuristic, premium-feeling portfolio website for "Jonas Websudio" — a web design studio — as the studio's own main showcase site. This one should feel genuinely expensive and cutting-edge: dark theme, glowing gradient accents, bold modern typography, smooth motion — not a generic template. Include: hero section, services, featured work (portfolio grid), process, why choose us (stats), pricing, and a contact/CTA section. Use the text below (leave exact design decisions — colors, fonts, layout — up to you, but push the futuristic/premium direction hard):

HERO:
Headline: Jonas Websudio
Subheadline: Websites that feel like the future — fast, sharp, and built to convert.

SERVICES:
- Website Design & Development — custom, high-performance websites built around your brand
- E-Commerce — online stores that are fast and easy to manage
- Branding & Identity — logos, color systems, brand guidelines
- Ongoing Support — updates, maintenance, hosting

FEATURED WORK:
- Amber Hour — specialty coffee brand landing page
- Bella Vista — Italian restaurant site
- Iron & Comb — modern barbershop
- Meridian Properties — real estate agency site
- Barrington & Cole — law firm site

PROCESS:
01 Discover — we learn about your business and goals
02 Design — a first draft ready to review in days, not weeks
03 Build — a fully working, responsive site
04 Launch — live, fast, and ready to grow with you

WHY JONAS WEBSUDIO:
- Websites delivered in days, not months
- Modern, distinctive design — never a generic template
- Fully responsive, fast-loading, built to convert
- Available in any language — English, Lithuanian, and more, on request
- Ongoing support after launch

PRICING:
- Starter — €490 — one-page site, up to 5 sections, mobile responsive
- Growth — €990 — multi-page site, custom design, contact/booking integration
- Premium — €1,890 — full custom build, animations, e-commerce or booking system, 3 months support

CONTACT:
Email: jonas.webstudio@gmail.com
Let's build something great. Get a free quote.

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/eb0bbbda-9b13-41ea-8a88-ad27bd80cdb8).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
