# Fix fresh-tab scrolling

## Goal
Every newly opened page starts at the top, including URLs that were copied or opened while a section hash such as `/#services` was active. Normal section links must continue to scroll to their targets after the page is already open.

## Changes
1. Take control of browser scroll restoration before page content renders, rather than waiting for the existing mounted effect.
2. Update the root scroll handler to distinguish the initial page load from later in-app navigation:
   - initial load/new tab: force the viewport to the top and remove a stale section hash from the displayed URL;
   - later header, hero, portfolio, and CTA hash navigation: smoothly scroll to the requested section as today.
3. Keep the existing TanStack Router setup and all current page design/content unchanged.

## Verification
- Open `/` in a fresh browser context and confirm `scrollY` is `0`.
- Open `/#services` and another section URL in a fresh context and confirm both start at `0` with the stale hash cleared.
- From the loaded page, click Services, Work, and Contact links and confirm each still scrolls to the correct section.
- Scroll down, reload/open a new tab, and confirm the page consistently returns to the hero without console errors.
