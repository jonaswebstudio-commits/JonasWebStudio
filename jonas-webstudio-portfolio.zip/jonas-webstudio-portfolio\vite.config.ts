// The shared config already includes: TanStack devtools (dev-only, first),
// tanstackStart, viteReact, tailwindcss, tsConfigPaths, nitro, VITE_* env
// injection, the @ path alias, React/TanStack dedupe and error logger plugins.
// Do NOT add those manually or the app breaks with duplicate plugins.
import { defineConfig } from "@lovable.dev/vite-tanstack-config";

export default defineConfig({
  tanstackStart: {
    // Redirect TanStack Start's bundled server entry to src/server.ts (our SSR
    // error wrapper). nitro/vite builds from this.
    server: { entry: "server" },
  },
  nitro: {
    // Build target. "vercel" writes .vercel/output, which Vercel deploys as-is.
    // Override with NITRO_PRESET for any other host (e.g. "node-server",
    // "netlify", "cloudflare-module").
    preset: process.env["NITRO_PRESET"] || "vercel",
  },
});
